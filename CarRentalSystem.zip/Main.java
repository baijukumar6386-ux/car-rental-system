import java.util.ArrayList;
import java.util.Scanner;

class Car {
    private String carId;
    private String brand;
    private String model;
    private double pricePerDay;
    private boolean available;

    public Car(String carId, String brand, String model, double pricePerDay) {
        this.carId = carId;
        this.brand = brand;
        this.model = model;
        this.pricePerDay = pricePerDay;
        this.available = true;
    }

    public String getCarId() { return carId; }
    public String getBrand() { return brand; }
    public String getModel() { return model; }
    public double getPricePerDay() { return pricePerDay; }
    public boolean isAvailable() { return available; }

    public void rentCar() { available = false; }
    public void returnCar() { available = true; }

    public void displayCar() {
        System.out.println("Car ID: " + carId + " | Brand: " + brand + " | Model: " + model +
                " | Price/Day: ₹" + pricePerDay + " | Status: " + (available ? "Available" : "Rented"));
    }
}

class Customer {
    private String customerId;
    private String name;
    private String phone;

    public Customer(String customerId, String name, String phone) {
        this.customerId = customerId;
        this.name = name;
        this.phone = phone;
    }

    public String getCustomerId() { return customerId; }
    public String getName() { return name; }
    public String getPhone() { return phone; }
}

class Rental {
    private Car car;
    private Customer customer;
    private int rentalDays;
    private boolean paymentDone;

    public Rental(Car car, Customer customer, int rentalDays) {
        this.car = car;
        this.customer = customer;
        this.rentalDays = rentalDays;
        this.paymentDone = false;
    }

    public Car getCar() { return car; }
    public Customer getCustomer() { return customer; }
    public int getRentalDays() { return rentalDays; }

    public double calculateTotalAmount() {
        return car.getPricePerDay() * rentalDays;
    }

    public void makePayment() {
        paymentDone = true;
    }

    public void generateInvoice() {
        System.out.println("\\n========== RENTAL INVOICE ==========");
        System.out.println("Customer ID   : " + customer.getCustomerId());
        System.out.println("Customer Name : " + customer.getName());
        System.out.println("Phone         : " + customer.getPhone());
        System.out.println("Car           : " + car.getBrand() + " " + car.getModel());
        System.out.println("Rental Days   : " + rentalDays);
        System.out.println("Total Amount  : ₹" + calculateTotalAmount());
        System.out.println("Payment       : " + (paymentDone ? "Paid" : "Pending"));
        System.out.println("===================================\\n");
    }
}

class CarRentalSystem {
    private ArrayList<Car> cars;
    private ArrayList<Rental> rentals;

    public CarRentalSystem() {
        cars = new ArrayList<>();
        rentals = new ArrayList<>();
    }

    public boolean adminLogin(String username, String password) {
        return username.equals("admin") && password.equals("1234");
    }

    public void addCar(Car car) {
        cars.add(car);
        System.out.println("Car added successfully.");
    }

    public void removeCar(String carId) {
        for (int i = 0; i < cars.size(); i++) {
            if (cars.get(i).getCarId().equalsIgnoreCase(carId)) {
                cars.remove(i);
                System.out.println("Car removed successfully.");
                return;
            }
        }
        System.out.println("Car not found.");
    }

    public void displayCars() {
        System.out.println("\\n========== CAR LIST ==========");
        for (Car car : cars) {
            car.displayCar();
        }
    }
}

public class Main {
    public static void main(String[] args) {
        System.out.println("Car Rental System Ready");
    }
}
