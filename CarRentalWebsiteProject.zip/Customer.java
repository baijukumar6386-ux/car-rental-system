public class Customer {
    private String customerId, name, phone;
    public Customer(String customerId, String name, String phone){
        this.customerId=customerId; this.name=name; this.phone=phone;
    }
    public String getName(){ return name; }
}