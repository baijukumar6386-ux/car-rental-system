import java.util.ArrayList;
public class CarRentalSystem {
    private ArrayList<Car> cars = new ArrayList<>();

    public CarRentalSystem() {
        cars.add(new Car("C101","Toyota","Fortuner",3000));
        cars.add(new Car("C102","Hyundai","Creta",2500));
    }

    public String getCarsHTML() {
        StringBuilder sb = new StringBuilder("<h2>Car List</h2>");
        for(Car car: cars){
            sb.append(car.getCarId()).append(" - ")
              .append(car.getBrand()).append(" ")
              .append(car.getModel()).append(" - ₹")
              .append(car.getPricePerDay()).append("<br>");
        }
        return sb.toString();
    }

    public boolean adminLogin(String u,String p){
        return u.equals("admin") && p.equals("1234");
    }
}