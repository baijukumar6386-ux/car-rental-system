import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
        CarRentalSystem system = new CarRentalSystem();
        String user = req.getParameter("username");
        String pass = req.getParameter("password");

        if(system.adminLogin(user, pass)){
            res.sendRedirect("dashboard.html");
        } else {
            res.getWriter().println("Invalid Login");
        }
    }
}