public class Car {
    private String carId, brand, model;
    private double pricePerDay;
    private boolean available = true;

    public Car(String carId, String brand, String model, double pricePerDay) {
        this.carId = carId; this.brand = brand; this.model = model; this.pricePerDay = pricePerDay;
    }

    public String getCarId(){ return carId; }
    public String getBrand(){ return brand; }
    public String getModel(){ return model; }
    public double getPricePerDay(){ return pricePerDay; }
    public boolean isAvailable(){ return available; }
    public void rentCar(){ available = false; }
    public void returnCar(){ available = true; }
}