import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

@WebServlet("/cars")
public class CarServlet extends HttpServlet {
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
        CarRentalSystem system = new CarRentalSystem();
        res.setContentType("text/html");
        res.getWriter().println(system.getCarsHTML());
    }
}